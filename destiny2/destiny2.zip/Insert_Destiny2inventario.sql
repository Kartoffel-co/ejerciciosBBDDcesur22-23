use destiny2
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (1,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (2,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (3,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (4,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (5,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (6,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (7,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (8,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (9,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (10,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (11,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (12,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (13,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (14,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (15,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (16,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (17,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (18,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (19,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (20,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (21,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (22,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (23,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (24,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (25,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (26,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (27,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (28,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (29,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (30,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (31,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (32,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (33,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (34,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (35,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (36,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (37,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (38,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (39,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (40,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (41,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (42,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (43,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (44,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (45,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (46,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (47,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (48,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (49,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (50,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (51,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (52,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (53,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (54,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (55,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (56,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (57,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (58,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (59,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (60,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (61,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (62,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (63,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (64,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (65,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (66,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (67,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (68,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (69,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (70,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (71,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (72,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (73,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (74,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (75,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (76,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (77,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (78,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (79,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (80,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (81,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (82,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (83,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (84,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (85,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (86,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (87,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (88,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (89,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (90,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (91,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (92,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (93,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (94,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (95,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (96,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (97,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (98,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (99,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (100,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (101,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (102,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (103,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (104,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (105,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (106,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (107,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (108,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (109,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (110,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (111,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (112,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (113,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (114,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (115,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (116,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (117,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (118,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (119,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (120,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (121,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (122,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (123,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (124,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (125,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (126,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (127,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (128,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (129,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (130,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (131,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (132,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (133,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (134,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (135,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (136,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (137,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (138,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (139,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (140,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (141,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (142,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (143,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (144,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (145,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (146,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (147,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (148,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (149,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (150,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (151,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (152,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (153,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (154,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (155,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (156,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (157,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (158,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (159,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (160,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (161,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (162,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (163,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (164,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (165,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (166,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (167,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (168,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (169,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (170,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (171,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (172,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (173,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (174,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (175,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (176,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (177,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (178,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (179,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (180,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (181,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (182,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (183,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (184,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (185,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (186,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (187,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (188,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (189,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (190,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (191,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (192,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (193,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (194,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (195,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (196,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (197,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (198,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (199,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (200,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (201,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (202,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (203,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (204,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (205,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (206,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (207,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (208,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (209,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (210,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (211,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (212,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (213,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (214,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (215,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (216,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (217,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (218,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (219,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (220,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (221,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (222,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (223,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (224,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (225,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (226,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (227,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (228,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (229,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (230,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (231,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (232,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (233,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (234,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (235,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (236,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (237,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (238,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (239,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (240,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (241,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (242,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (243,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (244,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (245,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (246,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (247,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (248,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (249,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (250,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (251,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (252,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (253,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (254,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (255,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (256,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (257,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (258,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (259,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (260,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (261,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (262,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (263,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (264,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (265,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (266,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (267,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (268,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (269,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (270,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (271,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (272,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (273,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (274,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (275,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (276,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (277,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (278,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (279,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (280,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (281,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (282,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (283,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (284,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (285,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (286,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (287,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (288,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (289,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (290,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (291,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (292,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (293,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (294,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (295,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (296,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (297,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (298,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (299,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (300,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (301,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (302,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (303,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (304,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (305,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (306,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (307,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (308,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (309,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (310,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (311,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (312,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (313,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (314,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (315,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (316,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (317,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (318,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (319,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (320,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (321,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (322,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (323,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (324,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (325,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (326,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (327,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (328,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (329,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (330,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (331,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (332,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (333,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (334,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (335,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (336,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (337,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (338,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (339,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (340,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (341,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (342,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (343,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (344,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (345,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (346,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (347,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (348,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (349,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (350,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (351,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (352,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (353,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (354,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (355,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (356,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (357,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (358,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (359,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (360,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (361,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (362,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (363,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (364,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (365,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (366,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (367,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (368,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (369,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (370,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (371,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (372,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (373,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (374,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (375,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (376,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (377,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (378,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (379,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (380,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (381,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (382,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (383,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (384,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (385,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (386,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (387,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (388,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (389,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (390,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (391,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (392,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (393,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (394,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (395,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (396,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (397,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (398,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (399,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (400,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (401,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (402,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (403,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (404,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (405,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (406,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (407,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (408,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (409,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (410,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (411,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (412,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (413,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (414,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (415,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (416,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (417,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (418,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (419,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (420,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (421,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (422,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (423,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (424,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (425,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (426,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (427,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (428,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (429,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (430,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (431,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (432,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (433,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (434,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (435,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (436,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (437,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (438,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (439,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (440,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (441,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (442,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (443,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (444,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (445,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (446,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (447,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (448,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (449,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (450,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (451,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (452,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (453,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (454,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (455,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (456,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (457,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (458,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (459,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (460,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (461,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (462,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (463,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (464,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (465,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (466,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (467,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (468,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (469,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (470,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (471,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (472,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (473,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (474,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (475,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (476,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (477,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (478,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (479,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (480,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (481,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (482,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (483,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (484,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (485,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (486,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (487,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (488,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (489,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (490,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (491,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (492,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (493,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (494,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (495,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (496,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (497,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (498,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (499,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (500,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (501,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (502,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (503,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (504,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (505,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (506,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (507,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (508,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (509,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (510,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (511,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (512,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (513,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (514,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (515,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (516,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (517,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (518,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (519,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (520,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (521,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (522,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (523,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (524,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (525,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (526,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (527,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (528,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (529,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (530,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (531,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (532,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (533,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (534,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (535,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (536,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (537,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (538,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (539,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (540,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (541,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (542,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (543,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (544,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (545,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (546,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (547,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (548,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (549,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (550,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (551,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (552,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (553,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (554,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (555,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (556,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (557,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (558,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (559,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (560,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (561,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (562,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (563,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (564,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (565,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (566,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (567,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (568,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (569,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (570,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (571,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (572,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (573,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (574,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (575,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (576,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (577,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (578,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (579,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (580,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (581,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (582,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (583,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (584,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (585,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (586,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (587,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (588,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (589,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (590,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (591,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (592,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (593,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (594,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (595,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (596,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (597,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (598,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (599,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');
INSERT INTO inventario(idPersonajes,armaPrimaria,armaSecundaria,armaTerciaria,casco,guantes,pecho,botas) VALUES (600,'placeholder','placeholder','placeholder','placeholder','placeholder','placeholder','placeholder');

-- ALTER TABLE inventario
-- DROP CONSTRAINT fkarmaPrimaria
-- ALTER TABLE inventario
-- DROP CONSTRAINT fkarmaSecundaria
-- ALTER TABLE inventario
-- DROP CONSTRAINT fkarmaTerciaria
-- ALTER TABLE inventario
-- DROP CONSTRAINT fkbotas
-- ALTER TABLE inventario
-- DROP CONSTRAINT fkcasco
-- ALTER TABLE inventario
-- DROP CONSTRAINT fkguantes
-- ALTER TABLE inventario
-- DROP CONSTRAINT fkpecho

-- insertar armas aleatorias en los huecos
DECLARE @contador INT = 1;
WHILE @contador <= 600
BEGIN
    UPDATE inventario
    SET armaPrimaria = (
        SELECT TOP 1 nombreArma
        FROM armas
        ORDER BY NEWID()
    )
    WHERE idPersonajes = @contador;

    UPDATE inventario
    SET armaSecundaria = (
        SELECT TOP 1 nombreArma
        FROM armas
        ORDER BY NEWID()
    )
    WHERE idPersonajes = @contador;

    UPDATE inventario
    SET armaTerciaria = (
        SELECT TOP 1 nombreArma
        FROM armas
        ORDER BY NEWID()
    )
    WHERE idPersonajes = @contador;

    SET @contador = @contador + 1;
END;

-- insertar armaduras aleatorias en los huecos

DECLARE @contador1 INT = 1
WHILE @contador1 <= 600
BEGIN
    UPDATE TOP(1) inventario
    SET casco = (SELECT TOP(1) nombreArmadura FROM armaduras WHERE tipoArmadura = 'casco' ORDER BY NEWID())
    WHERE idPersonajes = @contador1

    UPDATE TOP(1) inventario
    SET guantes = (SELECT TOP(1) nombreArmadura FROM armaduras WHERE tipoArmadura = 'guantes' ORDER BY NEWID())
    WHERE idPersonajes = @contador1

    UPDATE TOP(1) inventario
    SET pecho = (SELECT TOP(1) nombreArmadura FROM armaduras WHERE tipoArmadura = 'pecho' ORDER BY NEWID())
    WHERE idPersonajes = @contador1

    UPDATE TOP(1) inventario
    SET botas = (SELECT TOP(1) nombreArmadura FROM armaduras WHERE tipoArmadura = 'botas' ORDER BY NEWID())
    WHERE idPersonajes = @contador1

    SET @contador1 = @contador1 + 1
END

SELECT * FROM personajes

-- ALTER TABLE inventario
-- ADD CONSTRAINT fkarmaPrimaria
-- FOREIGN KEY (armaPrimaria) REFERENCES armas(nombreArma)
-- ALTER TABLE inventario
-- ADD CONSTRAINT fkarmaSecundaria
-- FOREIGN KEY (armaSecundaria) REFERENCES armas(nombreArma)
-- ALTER TABLE inventario
-- ADD CONSTRAINT fkarmaTerciaria
-- FOREIGN KEY (armaTerciaria) REFERENCES armas(nombreArma)
-- ALTER TABLE inventario
-- ADD CONSTRAINT fkbotas
-- FOREIGN KEY (botas) REFERENCES armaduras(nombreArmadura)
-- ALTER TABLE inventario
-- ADD CONSTRAINT fkcasco
-- FOREIGN KEY (casco) REFERENCES armaduras(nombreArmadura)
-- ALTER TABLE inventario
-- ADD CONSTRAINT fkguantes
-- FOREIGN KEY (guantes) REFERENCES armaduras(nombreArmadura)
-- ALTER TABLE inventario
-- ADD CONSTRAINT fkpecho
-- FOREIGN KEY (pecho) REFERENCES armaduras(nombreArmadura)